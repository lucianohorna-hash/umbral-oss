"""Provider-neutral failures eligible for one bounded server retry."""
class TransientNarrationError(ValueError):
    pass
