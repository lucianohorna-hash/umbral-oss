import json
from uuid import uuid4
import pytest
from fastapi.testclient import TestClient
from narrative.api import create_app
from narrative.db import Database,Record
from narrative.service import Engine
from narrative.narration_contract import unpack
from narrative.npc_autonomy import NPCCoordinator
from narrative.schemas import AutonomousAdvance,Acceptance
from sqlalchemy import select

class Provider:
    name='test'
    def __init__(self,data):self.data=data;self.calls=0
    def narrate(self,context,turns):self.calls+=1;return json.dumps(self.data)

def game(tmp_path):
    c=TestClient(create_app(tmp_path/'contract.db'));c.headers['X-CSRF-Token']=c.get('/api/bootstrap').json()['csrf_token']
    d=c.post('/api/wizard',json=dict(universe_name='Ficticio',campaign_name='Ensayo',protagonist_name='Ada')).json()
    db=Database(tmp_path/'contract.db');e=Engine(db)
    with db.session(True) as s:
        npc=Record(id=str(uuid4()),universe_id=d['universe_id'],kind='character',name='Iria',world_id=d['world_id'],
            data=__import__('narrative.schemas',fromlist=['Character']).Character(personality={'description':'Altanera'},goals=['Reparar el techo'],life={'wage_per_day':2},balance=4).model_dump())
        s.add(npc);s.flush();nid=npc.id
    return c,d,e,nid

def test_contract_blocks_wrong_identity_and_unknown_knowledge(tmp_path):
    c,d,e,nid=game(tmp_path);context=e.context(d['campaign_id'],'narrator')
    valid=dict(scene='Iria mira el camino.',cast=[dict(character_id=nid,name='Iria',personality={'description':'Altanera'})],claims=[dict(record_id=nid,field='name',value='Iria')])
    assert unpack(json.dumps(valid),context,strict=True)[0]=='Iria mira el camino.'
    with pytest.raises(ValueError):unpack(json.dumps({**valid,'claims':[dict(record_id=nid,field='name',value='Eva')]}),context,strict=True)
    with pytest.raises(ValueError):unpack(json.dumps({**valid,'cast':[dict(character_id=nid,name='Eva',personality={})]}),context,strict=True)
    with pytest.raises(ValueError):unpack('Una respuesta sin estructura.',context,strict=True)
    fact_id=str(uuid4())
    with e.db.session(True) as session:
        session.add(Record(id=fact_id,universe_id=d['universe_id'],kind='fact',name='Secreto del narrador',world_id=d['world_id'],data=dict(statement='La placa abre una puerta.',certainty='confirmed',known_by=[])))
    context=e.context(d['campaign_id'],'narrator')
    with pytest.raises(ValueError,match='conozca'):
        unpack(json.dumps({**valid,'knowledge_used':[dict(character_id=nid,fact_id=fact_id)]}),context,strict=True)
    with e.db.session(True) as session:
        fact=session.get(Record,fact_id);fact.data={**fact.data,'known_by':[nid]}
    context=e.context(d['campaign_id'],'narrator')
    assert unpack(json.dumps({**valid,'knowledge_used':[dict(character_id=nid,fact_id=fact_id)]}),context,strict=True)[3]['knowledge_checks']==1


def test_extractions_keep_literal_sources_and_never_approve_themselves(tmp_path):
    from narrative.narration import NarrationCoordinator
    from narrative.schemas import NarrationRequest,TurnInput
    c,d,e,nid=game(tmp_path);turn=e.add_turn(d['campaign_id'],TurnInput(role='user',content='Examino el suelo.'))
    scene='Hay una placa de metal con una espiral.'
    response=dict(scene=scene,candidates=[dict(evidence_quote=scene,record=dict(kind='detail',name='Placa con espiral',world_id=d['world_id'],campaign_id=d['campaign_id'],data=dict(statement=scene,certainty='confirmed')))])
    provider=Provider(response)
    result=NarrationCoordinator(e,provider).generate(d['campaign_id'],NarrationRequest(expected_version=1,request_id=str(uuid4()),expected_last_turn_id=turn['id']))
    snapshot=e.snapshot(d['universe_id'])
    assert snapshot['universe']['version']==1
    extracted=next(p for p in snapshot['proposals'] if p['id'] in result['provenance']['extracted_proposal_ids'])
    assert extracted['status']=='pending' and extracted['record']['data']['certainty']=='unknown'
    assert extracted['record']['source_ref']['excerpt']==scene
    assert result['provenance']['structured_source_id']
    assert not any(r['name']=='Placa con espiral' for r in snapshot['records'])


def test_bad_auxiliary_extraction_does_not_discard_scene_or_approve_bad_data(tmp_path):
    c,d,e,nid=game(tmp_path);context=e.context(d['campaign_id'],'narrator')
    scene='En la plaza hay una placa con una espiral.'
    bad=[dict(evidence_quote=scene,record=dict(kind='event',name='Plaza',world_id=d['world_id'],campaign_id=d['campaign_id'],data=dict(summary=scene,actions=['La gente camina.'],certainty='propuesto'))),
         dict(evidence_quote=scene,record=dict(kind='detail',name='Placa',world_id=d['world_id'],data=dict(statement=scene,features=['espiral']))),
         dict(evidence_quote=scene,record=dict(kind='place',name='Plaza',world_id=str(uuid4()),data=dict(description=scene)))]
    result=unpack(json.dumps(dict(scene=scene,candidates=bad)),context,strict=True)
    assert result[0]==scene and result[2]==[] and len(result[3]['quarantined_candidates'])==3
    # Critical identity claims remain blocking even alongside broken extraction.
    with pytest.raises(ValueError,match='antecedente'):
        unpack(json.dumps(dict(scene=scene,candidates=bad,claims=[dict(record_id=nid,field='name',value='Otro nombre')])),context,strict=True)


def test_real_role_conflict_still_blocks_instead_of_being_quarantined(tmp_path):
    c,d,e,nid=game(tmp_path);place_id=str(uuid4())
    role=dict(place_id=place_id,label='recepcionista',exclusive=True)
    with e.db.session(True) as session:
        session.add(Record(id=place_id,universe_id=d['universe_id'],world_id=d['world_id'],kind='place',name='Gremio',data=dict(description='Gremio ficticio.')))
        npc=session.get(Record,nid);npc.data={**npc.data,'roles':[role]}
    scene='Eva es la recepcionista del gremio.'
    data=dict(scene=scene,candidates=[dict(evidence_quote=scene,record=dict(kind='character',name='Eva',world_id=d['world_id'],campaign_id=d['campaign_id'],data=dict(roles=[role])))])
    with pytest.raises(ValueError,match='contradice'):
        unpack(json.dumps(data),e.context(d['campaign_id'],'narrator'),strict=True)


def test_literal_coverage_detects_omitted_npc_and_thin_personality_without_granting_knowledge(tmp_path):
    c,d,e,nid=game(tmp_path);context=e.context(d['campaign_id'],'narrator')
    plain=unpack(json.dumps(dict(scene='Iria permanece en el gremio.')),context,strict=True)
    assert plain[3]['coverage']['level']=='partial'
    assert plain[3]['coverage']['undeclared_entity_ids']==[nid]
    thin=unpack(json.dumps(dict(scene='Iria permanece en el gremio.',cast=[dict(character_id=nid,name='Iria',personality={})])),context,strict=True)
    assert thin[3]['coverage']['personality_not_declared_ids']==[nid]
    assert thin[3]['knowledge_checks']==0
    complete=unpack(json.dumps(dict(scene='Iria permanece en el gremio.',cast=[dict(character_id=nid,name='Iria',personality={'description':'Altanera'})])),context,strict=True)
    assert complete[3]['coverage']['level']=='declared'

def test_npc_simulation_is_independent_reviewed_and_preserves_player(tmp_path):
    c,d,e,nid=game(tmp_path)
    reason='Iria trabaja dos días en su oficio.'
    response=dict(summary=reason,intervals=[dict(character_id=nid,development='simulated',summary=reason)],actions=[dict(type='earn',character_id=nid,amount=4,claimed_days=2,reason=reason)])
    p=Provider(response);co=NPCCoordinator(e,p);request=AutonomousAdvance(expected_version=1,request_id=str(uuid4()),days=2)
    before=e.snapshot(d['universe_id'])
    draft=co.prepare(d['campaign_id'],request)
    assert not [i for i in draft['issues'] if i['severity'] in ('error','critical')],draft['issues']
    assert e.snapshot(d['universe_id'])['records']==before['records']
    co.prepare(d['campaign_id'],request);assert p.calls==1
    e.accept(draft['id'],Acceptance(expected_version=1,decision='Valido la simulación ficticia.',acknowledge_warnings=True))
    after=e.snapshot(d['universe_id'])
    assert next(r for r in after['records'] if r['id']==nid)['data']['balance']==8
    hero_before=next(r for r in before['records'] if r['id']==d['protagonist_id'])
    hero_after=next(r for r in after['records'] if r['id']==d['protagonist_id'])
    assert hero_before==hero_after
    assert next(r for r in after['records'] if r['kind']=='world')['data']['current_day']==2
    assert c.get('/api/campaigns/'+d['campaign_id']+'/turns').json()['turns']==[]

def test_npc_cannot_take_over_protagonist_or_invent_resources(tmp_path):
    c,d,e,nid=game(tmp_path)
    p=Provider(dict(summary='La protagonista camina.',intervals=[],actions=[dict(type='move',character_id=d['protagonist_id'],to_id=str(uuid4()))]))
    co=NPCCoordinator(e,p)
    with pytest.raises(Exception):co.prepare(d['campaign_id'],AutonomousAdvance(expected_version=1,request_id=str(uuid4()),days=1))
    reason='Iria cobra una fortuna sin salario suficiente.'
    p.data=dict(summary=reason,intervals=[],actions=[dict(type='earn',character_id=nid,amount=1000,claimed_days=1,reason=reason)])
    draft=co.prepare(d['campaign_id'],AutonomousAdvance(expected_version=1,request_id=str(uuid4()),days=1))
    assert any(i['code']=='unestablished_income' for i in draft['issues'])
