from uuid import uuid4
import pytest
from narrative.provider_errors import TransientNarrationError
from narrative.narration import NarrationCoordinator
from narrative.narration_jobs import PersistentNarration
from narrative.schemas import NarrationRequest
from narrative.service import Engine,DomainError
from test_long_campaigns import setup

class Provider:
    name='test'
    def __init__(self,errors):self.errors=list(errors);self.calls=0
    def narrate(self,context,turns):
        self.calls+=1
        if self.errors:raise self.errors.pop(0)
        return 'Prueba ficticia: Iria sigue en su puesto.'

def job(tmp_path,errors):
    c,d,db=setup(tmp_path);cid=d['campaign_id'];turn=c.post('/api/campaigns/'+cid+'/turns',json=dict(role='user',content='Observo el gremio.')).json()
    provider=Provider(errors);co=NarrationCoordinator(Engine(db),provider);jobs=PersistentNarration(Engine(db),co,retry_delay=0)
    request=NarrationRequest(expected_version=1,request_id=str(uuid4()),expected_last_turn_id=turn['id'])
    row=jobs.enqueue(cid,request,start=False)
    return c,d,provider,co,jobs,request,row

def test_transient_failure_retries_once_and_saves_one_response(tmp_path):
    c,d,p,co,jobs,request,row=job(tmp_path,[TransientNarrationError('server_error')]);cid=d['campaign_id']
    jobs.run(row['id']);result=jobs.status(cid,request.request_id)
    assert result['status']=='completed' and p.calls==2
    assert result['timings']['automatic_retries']==1
    assert len(c.get('/api/campaigns/'+cid+'/turns').json()['turns'])==2
    assert jobs.enqueue(cid,request)['status']=='completed' and p.calls==2
    extra=NarrationRequest(expected_version=1,request_id=str(uuid4()),expected_last_turn_id=result['turn_id'])
    with pytest.raises(DomainError):jobs.enqueue(cid,extra,start=False)
    with pytest.raises(DomainError):co.generate(cid,extra)
    assert p.calls==2

@pytest.mark.parametrize('reason',['quota exceeded','No cumple el formato de continuidad','Identidad contradictoria','max_output_tokens'])
def test_non_transient_failure_never_retries_automatically(tmp_path,reason):
    c,d,p,co,jobs,request,row=job(tmp_path,[ValueError(reason)])
    jobs.run(row['id']);assert jobs.status(d['campaign_id'],request.request_id)['status']=='failed'
    assert p.calls==1

def test_retry_budget_survives_worker_recreation_and_manual_retry(tmp_path):
    errors=[TransientNarrationError('server_error') for _ in range(4)]
    c,d,p,co,jobs,request,row=job(tmp_path,errors);cid=d['campaign_id']
    jobs.run(row['id']);assert p.calls==2
    restarted=PersistentNarration(jobs.engine,co,retry_delay=0)
    restarted.enqueue(cid,request,retry=True,start=False);restarted.run(row['id'])
    assert p.calls==3 and restarted.status(cid,request.request_id)['timings']['automatic_retries']==1
