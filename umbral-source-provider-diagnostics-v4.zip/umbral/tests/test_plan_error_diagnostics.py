from narrative.chatgpt_plan import stream_failure

def test_quota_is_distinguished_from_incomplete_output_and_server_failure():
    quota=str(stream_failure(dict(type='response.failed',response={'error':{'code':'subscription_sharing_usage_limit_exceeded','message':'private provider payload'}})))
    assert 'límite de uso' in quota and 'private provider payload' not in quota
    incomplete=str(stream_failure(dict(type='response.incomplete',response={'incomplete_details':{'reason':'max_output_tokens'}})))
    assert 'extensión' in incomplete and 'límite de uso' not in incomplete
    temporary=str(stream_failure(dict(type='error',code='server_error')))
    assert 'interrumpió' in temporary and 'límite de uso' not in temporary

def test_diagnostic_does_not_echo_arbitrary_or_sensitive_values():
    result=str(stream_failure(dict(type='error',error={'code':'Bearer private secret','message':'session-token'})))
    assert 'private secret' not in result and 'session-token' not in result and 'unknown' in result
