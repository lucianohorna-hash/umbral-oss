# Copia independiente cifrada

La copia automática en Supabase protege frente a errores de edición, pero no
frente a perder esa misma base. Esta opción prepara otra copia en los artefactos
del repositorio **privado** existente de GitHub. No necesita otra cuenta.

**Estado inicial: desactivada.** El código por sí solo no envía campañas a GitHub.
Antes de activarla, el propietario debe autorizar ese destino y el acceso de
lectura exclusivo de copias cifradas. También debe revisarse la cuota y mantener
el presupuesto de gasto adicional en cero. No se promete almacenamiento ilimitado.

Se exportan universos, registros, fuentes, propuestas, revisiones y conversaciones.
Se excluyen sesiones ChatGPT, contraseñas, claves, permisos del conector y trabajos
en curso. El servidor comprime y cifra con AES-256-GCM; una clave pública RSA de
3072 bits envuelve una clave aleatoria distinta por copia. GitHub recibe solamente
el archivo cifrado. La clave privada de recuperación no va a Render ni a GitHub.

Preparar claves en una carpeta privada nueva:

```powershell
python tools/recover_encrypted_backup.py keys data/backup-recovery
```

Conservar `RECOVERY-PRIVATE.pem` también en otro lugar seguro. Si se pierde, los
archivos cifrados no se pueden recuperar. El archivo no lleva contraseña: quien
posea la clave y una copia podrá leerla. No compartirlo ni añadirlo al repositorio.

Después de la autorización: guardar la clave pública en Render como
`NARRATIVE_BACKUP_PUBLIC_KEY`; generar un token aleatorio de 32 bytes o más,
guardar solo su SHA-256 como `NARRATIVE_BACKUP_TOKEN_SHA256` en Render y el token
como secreto `UMBRAL_BACKUP_TOKEN` en el repositorio privado. Ese token únicamente
autoriza `GET /api/backup.encrypted`, nunca la base sin cifrar ni cambios de canon.

Copiar `integrations/backup/github-actions.yml` a `.github/workflows/backup.yml`.
Definir las variables de repositorio `UMBRAL_BACKUP_URL` (origen HTTPS más
`/api/backup.encrypted`) y `UMBRAL_BACKUP_ENABLED=true`. La tarea descarga una copia
diaria, con retención de siete días y límite de 25 MB por descarga. La programación
de GitHub puede retrasarse; una ejecución fallida no equivale a una copia válida.

Probar la recuperación en un archivo nuevo antes de confiar en el sistema:

```powershell
python tools/recover_encrypted_backup.py recover umbral.encrypted.json data/backup-recovery/RECOVERY-PRIVATE.pem data/recuperacion-prueba.sqlite3
```

La herramienta comprueba autenticidad del cifrado, formato, integridad SQLite y
referencias. Nunca sobrescribe una base existente ni importa accesos de ChatGPT.
Revocar la automatización: desactivar la variable y quitar el hash del token de
Render. Las copias antiguas conservan su cifrado; la clave sigue siendo necesaria.
