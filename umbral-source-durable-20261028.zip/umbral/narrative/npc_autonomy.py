"""Model proposes NPC lives; canonical checks and explicit review govern effects."""
import json
import hashlib
from uuid import uuid5,NAMESPACE_URL
from pydantic import Field
from .schemas import Strict,SimulationInterval,Action,Event,RecordInput,ProposalInput
from .db import Proposal
from .service import DomainError,serialize

class NPCOutcome(Strict):
    summary: str=Field(min_length=1,max_length=30000)
    intervals: list[SimulationInterval]=Field(default_factory=list,max_length=20)
    actions: list[Action]=Field(default_factory=list,max_length=100)


def autonomy_identity(cid,request_id):
    return str(uuid5(NAMESPACE_URL,f'umbral/autonomy/{cid}/{request_id}'))


class NPCCoordinator:
    def __init__(self,engine,provider):self.engine,self.provider=engine,provider

    def prepare(self,cid,request):
        e=self.engine;identity=autonomy_identity(cid,request.request_id)
        signature=hashlib.sha256(request.model_dump_json().encode()).hexdigest()
        with e.db.session() as session:
            campaign=e._record(session,cid,'campaign');universe=e._universe(session,campaign.universe_id)
            prior=session.get(Proposal,identity)
            if prior:
                if prior.record.get('source_ref',{}).get('request_fingerprint')!=signature:
                    raise DomainError(409,'Este recibo ya se usó para otro avance del mundo.')
                return serialize(prior)
            e._version(universe,request.expected_version)
            records=e._records(session,universe.id);world=records[campaign.world_id]
            protected={r['data']['protagonist_id'] for r in records.values() if r['kind']=='campaign' and r['data'].get('status','active')=='active'}
            eligible={r['id']:r for r in records.values() if r['kind']=='character' and r['world_id']==world['id'] and r['id'] not in protected and str(r['data'].get('status','')).lower() not in ('muerto','dead','fallecido')}
            ids=request.relevant_character_ids
            if ids and any(i not in eligible for i in ids):raise DomainError(422,'Solo puedes simular NPC vivos de este mundo, sin protagonistas activos.')
            if not ids:
                ids=sorted(eligible,key=lambda i:(-bool(eligible[i]['data'].get('life',{}).get('plans')),-bool(eligible[i]['data'].get('goals')),-bool(eligible[i]['data'].get('routine')),i))[:20]
            start=world['data']['current_day'];end=start+request.days
            uid=universe.id
        context=e.context(cid,'narrator')
        context['npc_simulation']=dict(world_id=world['id'],start_day=start,end_day=end,eligible_character_ids=ids,protected_protagonist_ids=sorted(protected),
            instructions=[
                'Desarrolla la vida independiente de los NPC seleccionados, sin centrarlos en el protagonista ni darles misiones para él.',
                'Considera personalidad, conocimientos individuales, relaciones, ubicación, lesiones, obligaciones, recursos, metas y planes. Las emociones no fuerzan acciones explícitas.',
                'Los demás personajes conservan intervalos no desarrollados; no presumas inactividad ni inventes extraordinarios para todos.',
                'No narres ni decidas por los protagonistas protegidos. No reveles estos resultados al protagonista.',
                'No cambies personalidad estable: las emociones necesitan causa y change_basis con revisión actual y evidencia previa o current_event_excerpt literal del resumen.',
                'Todas las acciones necesitan IDs existentes. Los descubrimientos nuevos sin registro quedan como descripción para revisión, no como permisos inventados de conocimiento.',
                'Movimientos, transferencias y gasto respetan recursos y ubicaciones; las interacciones presenciales necesitan ubicaciones compatibles.',
                'life cambia solo profession, obligations, plans, projects, activity, resources, wage_per_day o recovery_days, con reason literal de summary.',
                'goal registra changes {goal:objetivo existente,status:planned|in_progress|completed|failed|deferred}; no presupongas éxito.',
                'status admite changes {status:sano|enfermo|incapacitado|muerto}, con reason literal; no resucites ni provoques muertes arbitrarias.',
                'earn requiere salario diario ya establecido, amount y claimed_days dentro del intervalo. recover requiere lesión y plazo de recuperación ya establecidos, injury y claimed_days.',
                'Si faltan causas, tiempo, recursos o información, usa deferred; no completes vacíos del pasado.'
            ])
        context['response_contract']=dict(format='JSON object only, no Markdown fences',shape=dict(summary='Resumen privado del narrador en español, con causas explícitas.',
            intervals=[dict(character_id='UUID seleccionado',development='simulated|routine|deferred|undeveloped',summary='Qué ocurre o qué queda pendiente')],
            actions=[dict(type='move|transfer|spend|reveal|interaction|emotion|injury|life|status|goal|earn|recover',character_id='UUID NPC',reason='cita literal de summary')]),
            rules=['Usa los campos estructurados de Action del motor. Sin acciones si solo procede una rutina. No incluyas campos fuera del contrato.'])
        if ids:
            raw=self.provider.narrate(context,[])
            text=raw.strip()
            if text.startswith('```'):text='\n'.join(text.splitlines()[1:-1])
            try:outcome=NPCOutcome.model_validate(json.loads(text))
            except (ValueError,TypeError):
                with e.db.session(True) as session:e._source(session,uid,'Simulación detenida por formato inválido',raw)
                raise DomainError(422,'La simulación no entregó resultados verificables. No se avanzó el reloj ni se cambió el canon.') from None
        else:
            outcome=NPCOutcome(summary='No hay NPC elegibles en este mundo. El intervalo queda sin desarrollo de personajes.',intervals=[],actions=[])
            raw=outcome.model_dump_json()
        if any(i.character_id not in ids for i in outcome.intervals):raise DomainError(422,'La simulación intenta desarrollar personajes no seleccionados.')
        if len({i.character_id for i in outcome.intervals})!=len(outcome.intervals):raise DomainError(422,'La simulación repite un intervalo de personaje.')
        referenced=set()
        for action in outcome.actions:
            for key in ('character_id','from_id','to_id'):
                identity_ref=getattr(action,key,None)
                if identity_ref in protected:raise DomainError(422,'La simulación intentó decidir por un protagonista activo.')
                if identity_ref in records and records[identity_ref]['kind']=='character':referenced.add(identity_ref)
        if referenced-set(ids):raise DomainError(422,'La simulación afecta personajes fuera del conjunto seleccionado.')
        listed={i.character_id for i in outcome.intervals}
        for identity_ref in ids:
            if identity_ref not in listed:outcome.intervals.append(SimulationInterval(character_id=identity_ref,development='undeveloped',summary='Intervalo no desarrollado; no se presume inactividad.'))
        event=Event(summary=outcome.summary,certainty='confirmed',day=end,participants=ids,actions=outcome.actions,
            simulation=dict(start_day=start,end_day=end,intervals=[i.model_dump() for i in outcome.intervals],policy='npc-autonomy-v1'))
        with e.db.session(True) as session:
            universe=e._universe(session,uid);e._version(universe,request.expected_version)
            prior=session.get(Proposal,identity)
            if prior:return serialize(prior)
            source=e._source(session,uid,'Simulación autónoma de NPC · propuesta',raw)
            record=RecordInput(kind='event',name=f'Vida independiente · días {start}–{end}',world_id=world['id'],source_id=source.id,
                source_ref=dict(autonomy_request_id=request.request_id,request_fingerprint=signature,selected_character_ids=ids),data=event.model_dump())
            proposal=e._new_proposal(session,universe,ProposalInput(title=f'Avance autónomo de {request.days} días',expected_version=request.expected_version,record=record),proposal_id=autonomy_identity(cid,request.request_id))
            return serialize(proposal)
