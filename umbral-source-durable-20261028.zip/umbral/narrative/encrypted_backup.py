"""Portable narrative data encrypted to an offline recovery key. No session export."""
import base64
import hashlib
import hmac
import json
import os
import zlib
from sqlalchemy import select
from .db import Universe,Source,Record,Proposal,Revision,Turn,now
from .recovery import row_data

MODELS=(Universe,Source,Record,Proposal,Revision,Turn)
FORMAT='umbral-backup-rsa-aesgcm-v1'

def _crypto():
    from cryptography.hazmat.primitives import serialization,hashes
    from cryptography.hazmat.primitives.asymmetric import rsa,padding
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    return serialization,hashes,rsa,padding,AESGCM

def keypair():
    serialization,_,rsa,_,_=_crypto()
    private=rsa.generate_private_key(public_exponent=65537,key_size=3072)
    return (private.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()),
            private.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo))

def export(db):
    with db.session() as session:
        return dict(format=1,created_at=now(),tables={m.__tablename__:[row_data(r) for r in session.scalars(select(m).order_by(m.id))] for m in MODELS})

def encrypt(payload,public_pem):
    serialization,hashes,rsa,padding,AESGCM=_crypto()
    public=serialization.load_pem_public_key(public_pem)
    if not isinstance(public,rsa.RSAPublicKey) or public.key_size<3072:raise ValueError('La copia requiere una clave pública RSA de al menos 3072 bits.')
    key=os.urandom(32);nonce=os.urandom(12)
    fingerprint=hashlib.sha256(public.public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)).hexdigest()
    aad=(FORMAT+':'+fingerprint).encode()
    content=zlib.compress(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8'))
    b64=lambda value:base64.b64encode(value).decode('ascii')
    return dict(format=FORMAT,key_id=fingerprint,key=b64(public.encrypt(key,padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),algorithm=hashes.SHA256(),label=None))),
                nonce=b64(nonce),ciphertext=b64(AESGCM(key).encrypt(nonce,content,aad)))

def decrypt(envelope,private_pem):
    serialization,hashes,_,padding,AESGCM=_crypto()
    if envelope.get('format')!=FORMAT:raise ValueError('Formato de copia desconocido.')
    private=serialization.load_pem_private_key(private_pem,password=None)
    public=private.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
    fingerprint=hashlib.sha256(public).hexdigest()
    if fingerprint!=envelope['key_id']:raise ValueError('La clave de recuperación no corresponde a esta copia.')
    decode=lambda key:base64.b64decode(envelope[key],validate=True)
    key=private.decrypt(decode('key'),padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),algorithm=hashes.SHA256(),label=None))
    compressed=AESGCM(key).decrypt(decode('nonce'),decode('ciphertext'),(FORMAT+':'+fingerprint).encode())
    unpacker=zlib.decompressobj();raw=unpacker.decompress(compressed,256_000_001)
    if len(raw)>256_000_000 or not unpacker.eof:raise ValueError('La copia excede el límite de recuperación.')
    payload=json.loads(raw)
    if payload.get('format')!=1 or set(payload.get('tables',{}))!={m.__tablename__ for m in MODELS}:raise ValueError('Contenido de copia no permitido.')
    return payload

def machine_authorized(header,token_sha256):
    if not token_sha256 or len(token_sha256)!=64 or not header or not header.startswith('Bearer '):return False
    token=header[7:]
    return len(token)<=512 and hmac.compare_digest(hashlib.sha256(token.encode()).hexdigest(),token_sha256)
