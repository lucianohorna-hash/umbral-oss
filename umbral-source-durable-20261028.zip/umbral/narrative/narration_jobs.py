"""Narration continues on the server, independent of an open browser request.
A lease prevents a second worker from spending another generation for the same job.
Interrupted requests require an explicit retry; they are never silently regenerated.
"""
from concurrent.futures import ThreadPoolExecutor
from threading import Lock, Event, Thread
from sqlalchemy import select
from datetime import datetime,timedelta,timezone
from uuid import NAMESPACE_URL,uuid5
from .db import NarrationJob,Turn,Proposal,now
from .schemas import NarrationRequest,AutonomousAdvance
from .npc_autonomy import autonomy_identity
from .service import DomainError


def job_identity(cid,request_id):
    return str(uuid5(NAMESPACE_URL,f'umbral/http/turn/{cid}/{request_id}'))


class PersistentNarration:
    def __init__(self,engine,coordinator,npc_coordinator=None):
        self.engine,self.coordinator=engine,coordinator
        self.npc_coordinator=npc_coordinator
        self.pool=ThreadPoolExecutor(max_workers=2,thread_name_prefix='umbral-narrator')
        self.scheduled=set();self.guard=Lock()

    def _public(self,row):
        return dict(kind=row.kind,phase=row.phase,timings=row.timings,proposal_id=row.turn_id if row.kind=='autonomy' else None,id=row.id,status=row.status,turn_id=row.turn_id,error=row.error,error_status=row.error_status,
                    attempts=row.attempts,updated_at=row.updated_at)

    def enqueue(self,cid,request,retry=False,start=True,kind='narration'):
        if kind not in ('narration','autonomy'):raise DomainError(422,'Tipo de trabajo desconocido.')
        identity=autonomy_identity(cid,request.request_id) if kind=='autonomy' else job_identity(cid,request.request_id)
        with self.engine.db.session(True) as session:
            c=self.engine._record(session,cid,'campaign')
            row=session.get(NarrationJob,identity)
            if row:
                if row.campaign_id!=cid or row.kind!=kind or row.request!=request.model_dump():
                    raise DomainError(409,'Este recibo corresponde a otra petición de narración.')
                if row.status in ('failed','interrupted') and retry:
                    row.status,row.error,row.lease_until='queued','',None
                    row.phase,row.timings='queued',{}
                    row.updated_at=now()
            else:
                row=NarrationJob(id=identity,kind=kind,universe_id=c.universe_id,campaign_id=cid,request=request.model_dump(),
                    status='queued',attempts=0,error='',error_status=502)
                session.add(row)
            session.flush()
            result=self._public(row)
        if start and result['status']=='queued':self.schedule(identity)
        return result

    def pending(self,cid):
        """Recover the receipt on another device, only for the latest player turn."""
        with self.engine.db.session() as session:
            self.engine._record(session,cid,'campaign')
            last=session.scalar(select(Turn).where(Turn.campaign_id==cid).order_by(Turn.created_at.desc(),Turn.id.desc()).limit(1))
            if not last or last.role!='user':return {'job':None}
            rows=session.scalars(select(NarrationJob).where(NarrationJob.campaign_id==cid,NarrationJob.kind=='narration').order_by(NarrationJob.created_at.desc()))
            row=next((r for r in rows if r.request.get('expected_last_turn_id')==last.id),None)
            if not row:return {'job':None}
            request=dict(row.request)
        return {'job':dict(self.status(cid,request['request_id']),request=request)}

    def schedule(self,identity):
        with self.guard:
            if identity in self.scheduled:return
            self.scheduled.add(identity)
        def work():
            try:self.run(identity)
            finally:
                with self.guard:self.scheduled.discard(identity)
        self.pool.submit(work)

    def status(self,cid,request_id,kind='narration'):
        if kind not in ('narration','autonomy'):raise DomainError(422,'Tipo de trabajo desconocido.')
        identity=autonomy_identity(cid,request_id) if kind=='autonomy' else job_identity(cid,request_id)
        with self.engine.db.session(True) as session:
            self.engine._record(session,cid,'campaign')
            row=session.get(NarrationJob,identity)
            if not row or row.campaign_id!=cid:raise DomainError(404,'No hay una petición guardada con este recibo.')
            # Reconcile a commit followed by worker/process interruption.
            turn=session.get(Turn,identity)
            proposal=session.get(Proposal,identity) if kind=='autonomy' else None
            if proposal and proposal.record.get('source_ref',{}).get('autonomy_request_id')==request_id:
                row.status,row.turn_id,row.error='completed',proposal.id,''
            elif turn and turn.role=='narrator' and turn.provenance.get('generation'):
                basis=turn.provenance['generation']
                if turn.canon_version!=row.request['expected_version'] or basis.get('requested_last_turn_id')!=row.request.get('expected_last_turn_id'):
                    row.status,row.error,row.error_status='failed','El recibo no corresponde al contexto de esta narración.',409
                else:row.status,row.turn_id,row.error='completed',turn.id,''
            elif row.status=='running' and row.lease_until and row.lease_until<now():
                row.status='interrupted';row.error='La narración se interrumpió. Tu intervención sigue guardada; puedes reintentar.'
            result=self._public(row)
        if result['status']=='queued':self.schedule(identity)
        return result

    def run(self,identity):
        with self.engine.db.session(True) as session:
            row=session.get(NarrationJob,identity)
            if not row or row.status!='queued':return
            row.status='running';row.attempts+=1;attempt=row.attempts
            row.lease_until=(datetime.now(timezone.utc)+timedelta(minutes=4)).isoformat();row.updated_at=now()
            kind=row.kind
            request=(AutonomousAdvance if kind=='autonomy' else NarrationRequest).model_validate(row.request);cid=row.campaign_id
        stopped=Event()
        def progress(phase=None,timings=None):
            with self.engine.db.session(True) as session:
                current=session.get(NarrationJob,identity)
                if current.attempts==attempt and current.status=='running':
                    current.lease_until=(datetime.now(timezone.utc)+timedelta(minutes=4)).isoformat()
                    if phase:current.phase=phase
                    if timings is not None:current.timings=timings
        def heartbeat():
            while not stopped.wait(30):
                try:progress()
                except Exception:pass  # A failed lease refresh never authorizes another generation.
        Thread(target=heartbeat,daemon=True,name='umbral-job-lease').start()
        try:
            turn=self.npc_coordinator.prepare(cid,request) if kind=='autonomy' else self.coordinator.generate(cid,request,progress=progress)
            with self.engine.db.session(True) as session:
                row=session.get(NarrationJob,identity)
                if row.attempts==attempt:
                    row.status,row.turn_id,row.error,row.updated_at='completed',turn['id'],'',now()
                    row.phase='completed'
        except Exception as error:
            detail=error.detail if isinstance(error,DomainError) else str(error) if isinstance(error,ValueError) else 'El narrador no pudo terminar. Tu intervención sigue guardada.'
            with self.engine.db.session(True) as session:
                row=session.get(NarrationJob,identity)
                if row.attempts==attempt:
                    row.status,row.error,row.error_status,row.updated_at='failed',str(detail)[:2000],getattr(error,'status',502),now()
                    row.phase='failed'
        finally:stopped.set()
