"""A provider-neutral response contract. Inferences stay reviewed proposals."""
import json
from typing import Any, Literal
from pydantic import Field
from .schemas import Strict, RecordInput, SceneCharacter, Event
from .memory import character_projection
from .continuity import check

class Claim(Strict):
    record_id: str
    field: Literal['name','location_id','owner_id','personality','psychology','balance','status','certainty']
    value: Any

class Candidate(Strict):
    evidence_quote: str=Field(min_length=1,max_length=5000)
    record: RecordInput

class KnowledgeUse(Strict):
    character_id: str
    fact_id: str

class Envelope(Strict):
    scene: str=Field(min_length=1,max_length=50000)
    cast: list[SceneCharacter]=Field(default_factory=list,max_length=100)
    claims: list[Claim]=Field(default_factory=list,max_length=100)
    knowledge_used: list[KnowledgeUse]=Field(default_factory=list,max_length=100)
    candidates: list[Candidate]=Field(default_factory=list,max_length=30)

CONTRACT = {
 'format':'JSON object only, no Markdown fences',
 'shape':{'scene':'Prosa narrativa para el jugador, en español. Sin explicaciones técnicas.',
          'cast':[{'character_id':'UUID canónico de un NPC establecido presente','name':'nombre canónico exacto','personality':{}}],
          'claims':[{'record_id':'UUID conocido','field':'name|location_id|owner_id|personality|psychology|balance|status|certainty','value':'valor canónico utilizado como antecedente'}],
          'knowledge_used':[{'character_id':'UUID del personaje que utiliza el conocimiento','fact_id':'UUID del dato utilizado'}],
          'candidates':[{'evidence_quote':'cita literal de scene que fundamenta este dato nuevo','record':{'kind':'character|place|item|detail|fact|event|relationship','name':'nombre del candidato','world_id':'UUID del mundo actual','campaign_id':'UUID de campaña actual','data':{}}}]},
 'rules':[
 'No añadas claves ajenas al contrato. Usa listas vacías cuando no corresponda.',
 'Cast y claims describen antecedentes establecidos, no estados futuros propuestos. Copia identidades y rasgos guardados; no los parafrasees como valores nuevos.',
 'Incluye los antecedentes que uses sobre identidad, personalidad, ubicación, recursos y conocimientos. No ocultes en la prosa una contradicción que omites de claims.',
 'Los datos nuevos se extraen de la escena como candidates y quedan para revisión, nunca son canon aprobado automáticamente.',
 'Data debe corresponder al tipo: character puede contener description/personality/location_id; place description/parent_id; item description/owner_id; detail statement/features/tags; fact statement; event summary/actions/day/certainty; relationship from_id/to_id/dimensions/explanation.',
 'No inventes UUID: las referencias existentes deben proceder del contexto. Los candidatos nuevos aún no tienen UUID y no pueden enlazarse entre sí como si ya hubieran sido validados.',
 'No reconstruyas pasado faltante. Parecidos entre objetos, nombres o símbolos son pistas de búsqueda, nunca prueba de identidad.',
 'NPC: actúan por personalidad, obligaciones, recursos, información, relaciones y objetivos propios. No esperan al protagonista ni deben ofrecerle misiones.',
 'Protege a los protagonistas de campañas activas. Una intervención explícita del propietario como narrador es su autoría, no un permiso para que tú inventes nuevas decisiones por su protagonista.'
 ]}


def unpack(content,context,strict=False):
    text=content.strip()
    if text.startswith('```'):
        lines=text.splitlines();text='\n'.join(lines[1:-1])
    if not text.startswith('{'):
        if strict:raise ValueError('El narrador no entregó una escena verificable. Tu decisión está guardada; reintenta sin volver a enviarla.')
        return content,[],[],dict(structured=False,claims=0),[]
    try:envelope=Envelope.model_validate(json.loads(text))
    except (ValueError,TypeError) as error:
        raise ValueError('La respuesta no cumple el formato de continuidad. No se incorporó una escena incompleta.') from None
    records={r['id']:r for r in context['records']}
    for claim in envelope.claims:
        record=records.get(claim.record_id)
        if not record:raise ValueError('El narrador atribuyó un antecedente a un registro inexistente.')
        actual=record['name'] if claim.field=='name' else record['data'].get(claim.field)
        if actual!=claim.value:raise ValueError('La escena contradice un antecedente guardado de '+record['name']+'. Se detuvo antes de mostrarla.')
    for use in envelope.knowledge_used:
        if use.character_id not in records or use.fact_id not in records:
            raise ValueError('La escena utiliza conocimiento sin una referencia válida.')
        visible=character_projection(records,use.character_id)
        if not any(r['id']==use.fact_id for r in visible):
            raise ValueError('Un personaje intenta usar información que no consta que conozca. La escena quedó detenida.')
    projected=dict(kind='event',name='Escena propuesta',world_id=context.get('world_id'),campaign_id=context['campaign_id'],
                   source_ref={},data=Event(summary=envelope.scene,cast=envelope.cast).model_dump())
    # Context has canonical campaign records; derive world without inventing one.
    projected['world_id']=records[context['campaign_id']]['world_id']
    issues,_=check(projected,records)
    if any(i['severity'] in ('error','critical') for i in issues):
        raise ValueError('El reparto de la escena contradice las fichas guardadas. Revisa el borrador del narrador.')
    for candidate in envelope.candidates:
        r=candidate.record
        if candidate.evidence_quote not in envelope.scene:raise ValueError('Una extracción no cita literalmente la escena. No se guardó como hecho.')
        if r.world_id!=projected['world_id'] or r.campaign_id not in (None,context['campaign_id']):
            raise ValueError('Una extracción intenta mezclar mundos o campañas.')
        if r.kind in ('world','campaign','knowledge','rule','temporal_link'):
            raise ValueError('Las decisiones fundacionales y el conocimiento requieren revisión específica, no extracción automática.')
        r.source_id=None
        if 'certainty' in r.data:r.data['certainty']='unknown'
        candidate_issues,_=check(r.model_dump(),records)
        if any(i['severity'] in ('error','critical') for i in candidate_issues):
            raise ValueError('Un dato extraído de la escena contradice las referencias o reglas guardadas. No se mostró la escena.')
    audit=dict(structured=True,claims=len(envelope.claims),knowledge_checks=len(envelope.knowledge_used),candidate_count=len(envelope.candidates))
    return envelope.scene,envelope.cast,envelope.candidates,audit,issues
