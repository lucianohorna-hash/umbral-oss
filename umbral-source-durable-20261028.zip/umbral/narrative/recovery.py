"""Transactional recovery snapshots. Latest state in each of 7 active-hour buckets.
Same database: protects against editing mistakes, not loss of the database itself.
"""
import hashlib
import json
from sqlalchemy import select
from .db import Universe, Source, Record, Proposal, Revision, Turn, RecoveryPoint, RecoveryDelta, uid, now

MODELS = (Source, Record, Proposal, Revision, Turn)


def row_data(row):
    return {c.name: getattr(row, c.name) for c in row.__table__.columns}


def digest(payload):
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()


def capture(session, identity, changes=None):
    universe=session.get(Universe,identity)
    if not universe:return
    stamp=now();bucket=stamp[:13]
    meta=session.execute(select(RecoveryPoint.id,RecoveryPoint.sha256,RecoveryPoint.sequence,RecoveryPoint.base_sha256).where(RecoveryPoint.universe_id==identity,RecoveryPoint.bucket==bucket)).first()
    if meta and changes:
        updates={};deleted={}
        for model,row_id in sorted(changes,key=lambda v:(v[0].__tablename__,v[1])):
            if model is Universe:continue
            if model not in MODELS:continue
            row=session.get(model,row_id)
            if row is None:deleted.setdefault(model.__tablename__,[]).append(row_id)
            else:updates.setdefault(model.__tablename__,[]).append(row_data(row))
        payload=dict(universe=row_data(universe),changes=updates,deleted=deleted)
        sequence=meta.sequence+1
        checksum=hashlib.sha256((meta.sha256+digest(payload)).encode()).hexdigest()
        session.add(RecoveryDelta(id=uid(),point_id=meta.id,sequence=sequence,previous_sha256=meta.sha256,sha256=checksum,payload=payload))
        # Do not load or rewrite the complete base snapshot for each message.
        session.execute(RecoveryPoint.__table__.update().where(RecoveryPoint.id==meta.id).values(sequence=sequence,base_sha256=meta.base_sha256 or meta.sha256,sha256=checksum,created_at=stamp,version=universe.version))
    else:
        payload={'format':1,'universe':row_data(universe),'tables':{}}
        for model in MODELS:
            payload['tables'][model.__tablename__]=[row_data(r) for r in session.scalars(select(model).where(model.universe_id==identity).order_by(model.id))]
        point=session.get(RecoveryPoint,meta.id) if meta else RecoveryPoint(id=uid(),universe_id=identity,bucket=bucket)
        if not meta:session.add(point)
        else:
            from sqlalchemy import delete
            session.execute(delete(RecoveryDelta).where(RecoveryDelta.point_id==point.id))
        point.created_at,point.version,point.payload=stamp,universe.version,payload
        point.sha256=point.base_sha256=digest(payload);point.sequence=0
    session.flush()
    old=list(session.scalars(select(RecoveryPoint.id).where(RecoveryPoint.universe_id==identity).order_by(RecoveryPoint.bucket.desc()).offset(7)))
    if old:
        from sqlalchemy import delete
        session.execute(delete(RecoveryDelta).where(RecoveryDelta.point_id.in_(old)))
        session.execute(delete(RecoveryPoint).where(RecoveryPoint.id.in_(old)))


def materialize(session,point):
    from copy import deepcopy
    payload=deepcopy(point.payload)
    root=digest(payload)
    if root!=(point.base_sha256 or point.sha256):raise ValueError('La base de la copia no supera la comprobación de integridad.')
    tables={name:{row['id']:row for row in rows} for name,rows in payload['tables'].items()}
    sequence=0
    for delta in session.scalars(select(RecoveryDelta).where(RecoveryDelta.point_id==point.id).order_by(RecoveryDelta.sequence)):
        sequence+=1
        expected=hashlib.sha256((root+digest(delta.payload)).encode()).hexdigest()
        if delta.sequence!=sequence or delta.previous_sha256!=root or delta.sha256!=expected:
            raise ValueError('La cadena de recuperación no supera la comprobación de integridad.')
        root=delta.sha256
        if delta.payload['universe']['id']!=point.universe_id:raise ValueError('La copia mezcla universos.')
        payload['universe']=deepcopy(delta.payload['universe'])
        for name,rows in delta.payload['changes'].items():
            if name not in tables:raise ValueError('Tipo de registro no permitido en la copia.')
            for row in rows:
                if row['universe_id']!=point.universe_id:raise ValueError('La copia mezcla universos.')
                tables[name][row['id']]=deepcopy(row)
        for name,ids in delta.payload['deleted'].items():
            if name not in tables:raise ValueError('Tipo de registro no permitido en la copia.')
            for identity in ids:tables[name].pop(identity,None)
    if sequence!=point.sequence or root!=point.sha256:raise ValueError('Faltan cambios o no coincide la integridad de la copia.')
    payload['tables']={name:list(rows.values()) for name,rows in tables.items()}
    return payload


def metadata(point):
    return {k: getattr(point, k) for k in ('id', 'universe_id', 'created_at', 'version', 'sha256')}


def restore_as_copy(session, point, label):
    payload = materialize(session,point)
    rows = [payload['universe']] + [r for items in payload['tables'].values() for r in items]
    mapping = {r['id']: uid() for r in rows}
    literal_fields = {'content','name','title','description','statement','summary','decision','reason','excerpt','routine','origin','relation','explanation','label','aliases','goals','capabilities','injuries'}
    def remap(value):
        if isinstance(value, str):
            return mapping.get(value, value)
        if isinstance(value, list):
            return [remap(v) for v in value]
        if isinstance(value, dict):
            return {mapping.get(k, k): v if k in literal_fields else remap(v) for k, v in value.items()}
        return value
    data = remap(payload['universe'])
    data['name'] = label
    universe = Universe(**data)
    session.add(universe)
    session.flush()
    # Core FK columns inserted with nullable links deferred until all record identities exist.
    for model in MODELS:
        items = [remap(r) for r in payload['tables'][model.__tablename__]]
        if model is Record:
            links = [(r['id'], r['world_id'], r['campaign_id']) for r in items]
            for item in items:
                item['world_id'] = item['campaign_id'] = None
            session.add_all(model(**r) for r in items)
            session.flush()
            for identity, world, campaign in links:
                row = session.get(Record, identity)
                row.world_id, row.campaign_id = world, campaign
        else:
            session.add_all(model(**r) for r in items)
        session.flush()
    # The recovered history is unchanged; provenance of restoration is an additional source.
    content = json.dumps(dict(recovered_from=point.id, original_universe=point.universe_id, sha256=point.sha256, at=now()))
    session.add(Source(id=uid(), universe_id=universe.id, title='Recuperación en universo separado', content=content,
                       sha256=hashlib.sha256(content.encode()).hexdigest()))
    session.flush()
    return universe.id
