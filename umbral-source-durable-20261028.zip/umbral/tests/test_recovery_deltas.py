from copy import deepcopy
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select,delete
from narrative.api import create_app
from narrative.db import Database,RecoveryPoint,RecoveryDelta
from narrative.recovery import materialize

def test_incremental_copy_preserves_base_and_detects_missing_or_tampered_changes(tmp_path):
    client=TestClient(create_app(tmp_path/'copy.db'));client.headers['X-CSRF-Token']=client.get('/api/bootstrap').json()['csrf_token']
    d=client.post('/api/wizard',json=dict(universe_name='Ficticio',campaign_name='Copia',protagonist_name='Ada')).json()
    db=Database(tmp_path/'copy.db')
    with db.session() as s:
        point=s.scalar(select(RecoveryPoint));base=deepcopy(point.payload)
    # A real v7 recovery point has no base hash yet. Its first delta must remain restorable.
    with db.session(True) as s:
        point=s.scalar(select(RecoveryPoint));point.base_sha256=''
    client.post('/api/campaigns/'+d['campaign_id']+'/turns',json=dict(role='user',content='La placa tiene una espiral.'))
    with db.session() as s:
        point=s.scalar(select(RecoveryPoint));assert point.payload==base and point.sequence>0
        assert materialize(s,point)['tables']['turns'][-1]['content']=='La placa tiene una espiral.'
    with db.session(True) as s:
        delta=s.scalar(select(RecoveryDelta));delta.payload={**delta.payload,'deleted':{'turns':['invented']}}
    with db.session() as s:
        with pytest.raises(ValueError):materialize(s,s.scalar(select(RecoveryPoint)))
    with db.session(True) as s:s.execute(delete(RecoveryDelta))
    with db.session() as s:
        with pytest.raises(ValueError):materialize(s,s.scalar(select(RecoveryPoint)))
