import hashlib,json,subprocess,sys
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from narrative.api import create_app
from narrative.db import Database,RuntimeSecret,BridgeGrant
from narrative.encrypted_backup import keypair,export,encrypt,decrypt
from narrative.security import CloudAccess

def test_encrypted_roundtrip_excludes_credentials_and_recovers_offline(tmp_path):
    c=TestClient(create_app(tmp_path/'game.db'));c.headers['X-CSRF-Token']=c.get('/api/bootstrap').json()['csrf_token']
    d=c.post('/api/wizard',json=dict(universe_name='Ficticio',campaign_name='Placa',protagonist_name='Ada')).json()
    c.post('/api/campaigns/'+d['campaign_id']+'/turns',json=dict(role='user',content='Recuerdo una placa de metal con una espiral.'))
    db=Database(tmp_path/'game.db')
    with db.session(True) as s:
        s.add(RuntimeSecret(name='test',host_id='private-host',sealed='NEVER_EXPORT_SESSION',revision=1))
    private,public=keypair();payload=export(db);envelope=encrypt(payload,public)
    assert 'NEVER_EXPORT_SESSION' not in json.dumps(payload)
    assert 'espiral' not in json.dumps(envelope)
    assert decrypt(envelope,private)==payload
    broken=dict(envelope,ciphertext=envelope['ciphertext'][::-1])
    with pytest.raises(Exception):decrypt(broken,private)
    other,_=keypair()
    with pytest.raises(ValueError):decrypt(envelope,other)
    (tmp_path/'backup.json').write_text(json.dumps(envelope),encoding='utf-8');(tmp_path/'key.pem').write_bytes(private)
    command=[sys.executable,'tools/recover_encrypted_backup.py','recover',str(tmp_path/'backup.json'),str(tmp_path/'key.pem'),str(tmp_path/'new.db')]
    first=subprocess.run(command,capture_output=True,text=True);assert first.returncode==0,first.stderr
    restored=export(Database(tmp_path/'new.db'));assert restored['tables']==payload['tables']
    assert subprocess.run(command,capture_output=True).returncode!=0

def test_backup_token_cannot_read_plaintext_or_mutate_canon(tmp_path,monkeypatch):
    private,public=keypair();token='fictional-backup-token-only-for-tests'
    monkeypatch.setenv('NARRATIVE_BACKUP_PUBLIC_KEY',public.decode())
    monkeypatch.setenv('NARRATIVE_BACKUP_TOKEN_SHA256',hashlib.sha256(token.encode()).hexdigest())
    access=CloudAccess.build('https://umbral.example','fictional-password-long','fictional-server-secret-at-least-32-characters')
    c=TestClient(create_app(tmp_path/'cloud.db',access=access),base_url='https://umbral.example')
    headers={'Authorization':'Bearer '+token}
    assert c.get('/api/backup.encrypted').status_code==401
    result=c.get('/api/backup.encrypted',headers=headers)
    assert result.status_code==200 and result.headers['cache-control']=='no-store'
    assert decrypt(result.json(),private)['tables']['universes']==[]
    assert c.get('/api/backup',headers=headers).status_code==401
    assert c.get('/api/bootstrap',headers=headers).status_code==401
    assert c.post('/api/universes',json={'name':'Forbidden'},headers=headers).status_code==401
    assert c.post('/api/backup.encrypted',headers=headers).status_code==401
