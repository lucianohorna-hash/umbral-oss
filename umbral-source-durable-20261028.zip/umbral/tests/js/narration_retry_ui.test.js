const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const vm=require('node:vm');
const source=fs.readFileSync(process.env.UMBRAL_RETRY_SOURCE||'narrative/static/app.js','utf8');
function harness(api){
 const values=new Map(),stages=[],timers=new Map(),nodes=new Map([['generate-turn',{}]]);let serial=0;
 const state={cid:'c',turns:[{id:'user'}],snapshot:{}};
 const context={api,s:state,version:()=>1,crypto:{randomUUID:()=> 'receipt'},localStorage:{getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)},experience:{stage:(cid,text)=>stages.push(text)},$:id=>nodes.get(id),narrating:new Map(),renderStory(){},Date,Error,JSON,Number,setInterval:fn=>{timers.set(++serial,fn);return serial;},clearInterval:id=>timers.delete(id),setTimeout,document:{hidden:false}};
 vm.createContext(context);vm.runInContext(source.slice(source.indexOf('  async function performNarration('),source.indexOf('  function pendingTurnKey(')),context);
 return {run:()=>context.requestNarration('c'),stages,timers,values,nodes};
}
test('failure reason is visible beside the composer, timer stops, receipt survives network errors',async()=>{
 const t=harness(async()=>{throw Error('Sin conexión temporal');});await assert.rejects(t.run(),/Sin conexión/);
 assert.match(t.stages.at(-1),/guardada.*Sin conexión.*Reintentar/);assert.equal(t.timers.size,0);assert.ok(t.values.size);
});
test('same pending retry shares one request and displays waiting before completion',async()=>{
 let finish,calls=0;const t=harness(()=>{calls++;return new Promise(resolve=>finish=resolve);});const first=t.run(),second=t.run();assert.equal(first,second);assert.equal(calls,1);assert.equal(t.nodes.get('generate-turn').textContent,'Esperando respuesta…');
 for(const fn of t.timers.values())fn();assert.match(t.stages.at(-1),/Conectando con el servidor/);
 finish({status:'completed'});await first;assert.equal(t.timers.size,0);assert.equal(t.values.size,0);
});
test('non-JSON server wakeup page produces a useful error instead of JSON syntax text',async()=>{
 const context={fetch:async()=>({status:503,json:async()=>{throw SyntaxError('Unexpected token <');}}),s:{csrf:'x'},Error,JSON,Array};vm.createContext(context);
 vm.runInContext(source.slice(source.indexOf('  async function api('),source.indexOf('  async function bootstrap(')),context);
 await assert.rejects(context.api('/test'),error=>error.status===503&&/despertando/.test(error.message)&&!/Unexpected/.test(error.message));
});
