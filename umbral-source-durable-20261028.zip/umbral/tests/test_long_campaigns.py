from uuid import uuid4
from fastapi.testclient import TestClient
from narrative.api import create_app
from narrative.narration import NarrationCoordinator
from narrative.narration_jobs import PersistentNarration
from narrative.schemas import NarrationRequest
from narrative.service import Engine
from narrative.db import Database, NarrationJob

class Provider:
    name='test'
    def __init__(self):self.calls=0
    def narrate(self,context,turns):self.calls+=1;return 'Prueba ficticia: el camino sigue abierto.'

def setup(tmp_path):
    c=TestClient(create_app(tmp_path/'game.db'));c.headers['X-CSRF-Token']=c.get('/api/bootstrap').json()['csrf_token']
    d=c.post('/api/wizard',json=dict(universe_name='Ficticio',campaign_name='Páginas',protagonist_name='Ada')).json()
    return c,d,Database(tmp_path/'game.db')

def test_turn_pages_and_compact_snapshot_never_transfer_old_scene_bodies(tmp_path):
    c,d,db=setup(tmp_path);route='/api/campaigns/'+d['campaign_id']
    for i in range(13):
        result=c.post(route+'/turns',json=dict(role='narrator',content=f'SECRETO_DE_ARCHIVO_{i:03d} '+('texto antiguo '*30)))
        assert result.status_code==200,result.text
    page=c.get(route+'/turns?limit=5').json()
    assert len(page['turns'])==5 and '008' in page['turns'][0]['content'] and page['has_more']
    previous=c.get(route+'/turns?limit=5&before='+page['next_before']).json()
    assert len(previous['turns'])==5 and '003' in previous['turns'][0]['content']
    assert set(t['id'] for t in previous['turns']).isdisjoint(t['id'] for t in page['turns'])
    compact=c.get('/api/universes/'+d['universe_id']+'?compact=true')
    assert compact.status_code==200
    assert 'SECRETO_DE_ARCHIVO_' not in compact.text
    assert len(c.get(route+'/turns').json()['turns'])==13
    assert c.get(route+'/turns?limit=101').status_code==422
    other=c.post('/api/wizard',json=dict(universe_name='Otro',campaign_name='Otra',protagonist_name='B')).json()
    assert c.get('/api/campaigns/'+other['campaign_id']+'/turns?limit=5&before='+page['next_before']).status_code==422

def test_job_survives_new_coordinator_and_retries_do_not_generate_twice(tmp_path):
    c,d,db=setup(tmp_path);route='/api/campaigns/'+d['campaign_id']
    turn=c.post(route+'/turns',json=dict(role='user',content='Observo.')).json()
    p=Provider();engine=Engine(db);jobs=PersistentNarration(engine,NarrationCoordinator(engine,p))
    request=NarrationRequest(expected_version=1,request_id=str(uuid4()),expected_last_turn_id=turn['id'])
    row=jobs.enqueue(d['campaign_id'],request,start=False)
    restarted=PersistentNarration(engine,NarrationCoordinator(engine,p));restarted.run(row['id'])
    assert restarted.status(d['campaign_id'],request.request_id)['status']=='completed'
    assert restarted.enqueue(d['campaign_id'],request)['status']=='completed'
    assert p.calls==1
    with db.session(True) as s:
        job=s.get(NarrationJob,row['id']);job.status='running';job.turn_id=None
    assert restarted.status(d['campaign_id'],request.request_id)['status']=='completed'
    assert p.calls==1

def test_expired_job_is_interrupted_not_silently_regenerated(tmp_path):
    c,d,db=setup(tmp_path);p=Provider();jobs=PersistentNarration(Engine(db),NarrationCoordinator(Engine(db),p))
    request=NarrationRequest(expected_version=1,request_id=str(uuid4()),expected_last_turn_id=None)
    row=jobs.enqueue(d['campaign_id'],request,start=False)
    with db.session(True) as s:
        j=s.get(NarrationJob,row['id']);j.status='running';j.lease_until='2000-01-01T00:00:00+00:00'
    assert jobs.status(d['campaign_id'],request.request_id)['status']=='interrupted'
    assert p.calls==0


def test_another_device_recovers_receipt_without_regenerating(tmp_path):
    c,d,db=setup(tmp_path);route='/api/campaigns/'+d['campaign_id']
    turn=c.post(route+'/turns',json=dict(role='user',content='Espero junto a la placa.')).json()
    provider=Provider();engine=Engine(db);jobs=PersistentNarration(engine,NarrationCoordinator(engine,provider))
    request=NarrationRequest(expected_version=1,request_id=str(uuid4()),expected_last_turn_id=turn['id'])
    row=jobs.enqueue(d['campaign_id'],request,start=False)
    # Do not schedule in this check: another device should only recover the receipt.
    jobs.schedule=lambda identity:None
    pending=jobs.pending(d['campaign_id'])['job']
    assert pending['request']==request.model_dump() and pending['status']=='queued'
    jobs.run(row['id'])
    completed=jobs.status(d['campaign_id'],request.request_id)
    assert completed['status']=='completed' and completed['phase']=='completed'
    assert set(completed['timings'])=={'memory','model','continuity','saving'}
    assert jobs.pending(d['campaign_id'])=={'job':None}
    assert provider.calls==1
