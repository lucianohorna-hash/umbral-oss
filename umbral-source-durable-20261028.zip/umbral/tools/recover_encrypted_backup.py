"""Offline recovery; never overwrites an existing database or requests AI."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from narrative.encrypted_backup import decrypt,keypair,MODELS
from narrative.db import Database
from sqlalchemy import text

def main():
    parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='command',required=True)
    keys=sub.add_parser('keys');keys.add_argument('directory',type=Path)
    recover=sub.add_parser('recover');recover.add_argument('backup',type=Path);recover.add_argument('private_key',type=Path);recover.add_argument('destination',type=Path)
    args=parser.parse_args()
    if args.command=='keys':
        args.directory.mkdir(parents=True,exist_ok=False)
        private,public=keypair()
        for name,data in [('RECOVERY-PRIVATE.pem',private),('backup-public.pem',public)]:
            path=args.directory/name
            with path.open('xb') as output:output.write(data)
            path.chmod(0o600)
        print('Claves creadas. Conserva RECOVERY-PRIVATE.pem fuera del servidor y del repositorio.')
        return
    if args.destination.exists():raise ValueError('La recuperación necesita una ruta nueva. No se sobrescribirá ningún archivo.')
    payload=decrypt(json.loads(args.backup.read_text(encoding='utf-8')),args.private_key.read_bytes())
    db=Database(args.destination)
    with db.session(True) as session:
        session.execute(text('PRAGMA defer_foreign_keys=ON'))
        for model in MODELS:
            rows=payload['tables'][model.__tablename__]
            if rows:session.execute(model.__table__.insert(),rows)
    with db.engine.connect() as connection:
        if connection.execute(text('PRAGMA integrity_check')).scalar()!='ok' or connection.execute(text('PRAGMA foreign_key_check')).fetchall():raise ValueError('La recuperación no supera la comprobación de integridad.')
    db.engine.dispose();print('Copia recuperada en una base nueva. Sin sesiones ni accesos de ChatGPT.')

if __name__=='__main__':main()
