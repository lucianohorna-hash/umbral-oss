"""Immutable migration revisions."""
