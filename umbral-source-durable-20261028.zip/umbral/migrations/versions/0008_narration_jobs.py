"""Durable private narration requests and chronological page index."""
from alembic import op
import sqlalchemy as sa
revision='0008'
down_revision='0007'
branch_labels=None
depends_on=None


def upgrade():
    op.add_column('recovery_points',sa.Column('base_sha256',sa.String(64),nullable=False,server_default=''))
    op.add_column('recovery_points',sa.Column('sequence',sa.Integer(),nullable=False,server_default='0'))
    op.create_table('recovery_deltas',
        sa.Column('id',sa.String(),primary_key=True),
        sa.Column('point_id',sa.String(),sa.ForeignKey('recovery_points.id',ondelete='CASCADE'),nullable=False),
        sa.Column('sequence',sa.Integer(),nullable=False),
        sa.Column('previous_sha256',sa.String(64),nullable=False),
        sa.Column('sha256',sa.String(64),nullable=False),
        sa.Column('payload',sa.JSON(),nullable=False),
        sa.UniqueConstraint('point_id','sequence'))
    op.create_index('ix_recovery_deltas_point_id','recovery_deltas',['point_id'])
    op.create_table('narration_jobs',
        sa.Column('id',sa.String(),primary_key=True),
        sa.Column('kind',sa.String(),nullable=False,server_default='narration'),
        sa.Column('universe_id',sa.String(),sa.ForeignKey('universes.id'),nullable=False),
        sa.Column('campaign_id',sa.String(),sa.ForeignKey('records.id'),nullable=False),
        sa.Column('request',sa.JSON(),nullable=False),
        sa.Column('status',sa.String(),nullable=False),
        sa.Column('phase',sa.String(),nullable=False,server_default='queued'),
        sa.Column('timings',sa.JSON(),nullable=False,server_default='{}'),
        sa.Column('lease_until',sa.String(),nullable=True),
        sa.Column('attempts',sa.Integer(),nullable=False),
        sa.Column('turn_id',sa.String(),nullable=True),
        sa.Column('error',sa.Text(),nullable=False),
        sa.Column('error_status',sa.Integer(),nullable=False),
        sa.Column('updated_at',sa.String(),nullable=False),
        sa.Column('created_at',sa.String(),nullable=False))
    for col in ('universe_id','campaign_id'):
        op.create_index('ix_narration_jobs_'+col,'narration_jobs',[col])
    op.create_index('ix_turns_campaign_created_id','turns',['campaign_id','created_at','id'])
    bind=op.get_bind()
    if bind.dialect.name=='postgresql':
        op.execute('ALTER TABLE narrative_core.recovery_deltas ENABLE ROW LEVEL SECURITY')
        op.execute('REVOKE ALL ON TABLE narrative_core.recovery_deltas FROM PUBLIC')
        op.execute('ALTER TABLE narrative_core.narration_jobs ENABLE ROW LEVEL SECURITY')
        op.execute('REVOKE ALL ON TABLE narrative_core.narration_jobs FROM PUBLIC')
        for role in bind.execute(sa.text("SELECT rolname FROM pg_roles WHERE rolname IN ('anon','authenticated')")).scalars():
            op.execute(f'REVOKE ALL ON TABLE narrative_core.narration_jobs FROM "{role}"')
            op.execute(f'REVOKE ALL ON TABLE narrative_core.recovery_deltas FROM "{role}"')


def downgrade():
    raise RuntimeError('Las peticiones persistentes deben conservarse.')
